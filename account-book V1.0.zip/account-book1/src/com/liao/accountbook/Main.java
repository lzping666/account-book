package com.liao.accountbook;

public class Main {
    public static void main(String[] args) {
        system sys = new system();
        sys.run();
    }
}
