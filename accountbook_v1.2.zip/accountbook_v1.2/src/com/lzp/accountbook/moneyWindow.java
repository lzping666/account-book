package com.lzp.accountbook;

//界面
public class moneyWindow {
    public void show (){
        System.out.println("========欢迎来到LZP记账本系统========");
        System.out.println("       1.查询收入支出统计            ");
        System.out.println("       2.收入(存钱)                 ");
        System.out.println("       3.支出(取钱)                 ");
        System.out.println("       4.退出                       ");
        System.out.println("       \uD83C\uDD2C版权所有，禁止盗版");
        System.out.println("===================================");
        System.out.println("请按数字输入以下指令:          ");
    }
}