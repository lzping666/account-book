package com.lzp.accountbook;

public class Main {
    public static void main(String[] args) {
        moneySystem sys = new moneySystem();
        sys.run();
    }
}
